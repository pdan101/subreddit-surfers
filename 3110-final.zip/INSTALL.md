# Installation Instructions

## Run the following commands in the terminal:
```
opam install -y utop odoc ounit2 qcheck bisect_ppx menhir ocaml-lsp-server ocamlformat ocamlformat-rpc ANSITerminal pyml

sudo apt install python-pip

pip install vaderSentiment

make demo_one
```